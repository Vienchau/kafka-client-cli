package main

import "kcli/cmd"

func main() {
	cmd.Execute()
}
